This library extends the performance of miller puckette's pure data (pd).

iem_roomsim is written by Thomas Musil from IEM Graz Austria
 and it is compatible to miller puckette's pd-0.37-3 to pd-0.39-2.
see also LICENCE.txt, GnuGPL.txt.

iem_roomsim contains 2 objects: 
"cart2del_damp_2d" and "cart2del_damp_3d".

this are 2 mirror source method rendering objects, they calculate the radius distance,
the delay time and the spheric coordinates in case of 3D or the polar coordinates in case of 2D
of all the first and second reflections between an subjekt and an object in a cuboid room.
