This library extends the performance of miller puckette's pure data (pd).

iem_atan2 is written by Thomas Musil from IEM Graz Austria
 and it is compatible to miller puckette's pd-0.37-3 to pd-0.39-2.
see also LICENCE.txt, GnuGPL.txt.

iem_atan2 is an object, that calculates the inverse tangent of Y and X.

