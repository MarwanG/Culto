This library extends the performance of miller puckette's pure data (pd).

iem_delay is written by Thomas Musil from IEM Graz Austria
 and it is compatible up to miller puckette's pd-0.42-5.
see also LICENCE.txt, GnuGPL.txt.

iem_delay contains 4 objects: 
"block_delay~", "n_delay1p_line~", "n_delay2p_line~" and "nz~".

block_delay~ : Constant signal delay of one blocksize.

n_delay1p_line~ : One signal inlet and n delay tap outlets. Delay times change every sample without interpolation and are given in ms.

n_delay2p_line~ : One signal inlet and n delay tap outlets. Delay times change every sample with a 2-point interpolation and are given in ms.

nz~ : One signal inlet and n delay tap outlets. Delay times change at least every blocksize and are given in samples.