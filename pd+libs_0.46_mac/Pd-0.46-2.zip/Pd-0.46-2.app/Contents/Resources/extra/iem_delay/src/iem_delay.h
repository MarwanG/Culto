/* For information on usage and redistribution, and for a DISCLAIMER OF ALL
* WARRANTIES, see the file, "LICENSE.txt," in this distribution.

iem_delay written by Thomas Musil (c) IEM KUG Graz Austria 2002 - 2013 */

#ifndef __IEMDELAY_H__
#define __IEMDELAY_H__

#define DELLINE_DEF_VEC_SIZE 64

#endif
