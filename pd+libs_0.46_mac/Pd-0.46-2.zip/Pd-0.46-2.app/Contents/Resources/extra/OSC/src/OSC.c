/* For information on usage and redistribution, and for a DISCLAIMER OF ALL
* WARRANTIES, see the file, "LICENSE.txt," in this distribution.

OSC written by Martin Peach, 20060424 */


#include "m_pd.h"

static t_class *OSC_class;

static void *OSC_new(void)
{
  t_object *x = (t_object *)pd_new(OSC_class);
  
  return (x);
}

void packOSC_setup(void);
void pipelist_setup(void);
void routeOSC_setup(void);
void unpackOSC_setup(void);

/* ------------------------ setup routine ------------------------- */

void OSC_setup(void)
{
  OSC_class = class_new(gensym("OSC"), OSC_new, 0,
    sizeof(t_object), CLASS_NOINLET, 0);
  
  packOSC_setup();
  pipelist_setup();
  routeOSC_setup();
  unpackOSC_setup();
	post("OSC (R-1.17) library loaded!   (c) Martin Peach 01.2008");
}
