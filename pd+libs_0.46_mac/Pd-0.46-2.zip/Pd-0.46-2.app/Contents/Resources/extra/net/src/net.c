/* udpsend.c 20060424. Martin Peach did it based on x_net.c. x_net.c header follows: */
/* Copyright (c) 1997-1999 Miller Puckette.
* For information on usage and redistribution, and for a DISCLAIMER OF ALL
* WARRANTIES, see the file, "LICENSE.txt," in this distribution.  */

/* network */

#include "m_pd.h"

static t_class *net_class;

static void *net_new(void)
{
  t_object *x = (t_object *)pd_new(net_class);
  
  return (x);
}

void tcpclient_setup(void);
void tcpreceive_setup(void);
void tcpsend_setup(void);
void tcpserver_setup(void);
void udpreceive_setup(void);
void udpsend_setup(void);

/* ------------------------ setup routine ------------------------- */

void net_setup(void)
{
  net_class = class_new(gensym("net"), net_new, 0,
    sizeof(t_object), CLASS_NOINLET, 0);
  
  tcpclient_setup();
  tcpreceive_setup();
  tcpsend_setup();
  tcpserver_setup();
  udpreceive_setup();
  udpsend_setup();
  
  post("net (R-1.17) library loaded!   (c) Martin Peach 01.2008");
}


