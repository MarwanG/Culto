iem_dp is a double precision library written by Thomas Musil and IOhannes Zmoelnig

The goal of this library is to allow more than 24 bit accurate access to arrays and delay-lines.
That means: with 32-bit IEEE floatingpoint we have a 23 bit mantissa with a resolution of 1 to 8388608.
If you want to access to an array ( size greater than 8388608 ) by tabread4, you get a staircase-shaped output.
The objects of this library work internal with double or 32-bit integer instead 24-bit mantissa of 32-bit float. To connect this higher resolution, we need 2 signal or 2 message cords. One for the float casted number and one for the difference to the higher resolution number.

ftohex
symtodp
dptosym
dptohex
vline~~
samphold~~
wrap~~
phasor~~
print~~
add__ , +__ , +''
sub__ , -__ , -''
mul__ , *__ , *''
div__ , /__ , /''
add~~ , +~~
sub~~ , -~~
mul~~ , *~~
div~~ , /~~
tabwrite__ , tabwrite''
tabread__ , tabread''
tabread4__ , tabread4''
tabwrite~~
tabread~~
tabread4~~
max__ , max''
min__ , min''
max~~
min~~
random__ , random''
delwrite~~
delread~~
vd~~